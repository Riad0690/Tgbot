require('dotenv').config();
const { Telegraf } = require('telegraf');
const connectDB = require('./database');

const bot = new Telegraf(process.env.BOT_TOKEN);

// MongoDB Connection
connectDB();

bot.start((ctx) => ctx.reply('🚀 Welcome to the Telegram Bot!'));
bot.launch();

console.log('✅ Bot is running...');
