const User = require('../models/User');

module.exports = async (ctx) => {
    const userId = ctx.message.from.id.toString();

    let user = await User.findOne({ userId });
    if (!user) {
        return ctx.reply('❌ You are not registered yet! Use /start');
    }

    ctx.reply(`👤 **Your Info:**\n🆔 User ID: ${userId}\n💰 Coins: ${user.coins}\n⭐ XP: ${user.xp}\n📅 Joined: ${user.joinedAt}`);
};
