const User = require('../models/User');

module.exports = async (ctx) => {
    const userId = ctx.message.from.id.toString();
    const username = ctx.message.from.username || 'NoUsername';

    let user = await User.findOne({ userId });
    if (!user) {
        user = new User({ userId, username });
        await user.save();
        ctx.reply(`🚀 Welcome, @${username}! Your data has been saved ✅`);
    } else {
        ctx.reply(`👋 Welcome back, @${username}!`);
    }
};
