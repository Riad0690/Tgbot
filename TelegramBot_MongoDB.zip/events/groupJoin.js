const Group = require('../models/Group');

module.exports = async (ctx) => {
    if (!ctx.chat || ctx.chat.type !== 'supergroup') return;

    const groupId = ctx.chat.id.toString();
    const groupName = ctx.chat.title;

    let group = await Group.findOne({ groupId });
    if (!group) {
        group = new Group({ groupId, groupName });
        await group.save();
        ctx.reply(`✅ Group **${groupName}** has been registered!`);
    } else {
        ctx.reply(`🔹 Group **${groupName}** is already in the database!`);
    }
};
